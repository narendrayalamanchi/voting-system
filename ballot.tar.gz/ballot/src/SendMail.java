package ballot;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
public class SendMail {

    int track;
    public boolean mailSender(String k,String name,String b)
    {
        Properties p = new Properties();
        p.put("mail.smtp.host", "smtp.gmail.com");
	p.put("mail.smtp.socketFactory.port", "465");
	p.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
	p.put("mail.smtp.auth", "true");
	p.put("mail.smtp.port", "465");
	Session session = Session.getDefaultInstance(p,new javax.mail.Authenticator()
										{
                                                                                    @Override
                                                                                    protected PasswordAuthentication getPasswordAuthentication()
                                                                                    {
											return new PasswordAuthentication("tnonlinevoting@gmail.com","99421421");
                                                                                    }
										});
    try 
   {
	Message m = new MimeMessage(session);
	m.setFrom(new InternetAddress("tnonlinevoting@gmail.com"));
	m.setRecipients(Message.RecipientType.TO,InternetAddress.parse(k));
        m.setSubject("DONT REPLY");
        m.setText("Dear "+"name"+"\n\nVOINT SUCESSFULL FOR "+b);
        Transport.send(m);
        return true;
    } 
    catch (MessagingException e) 
    {
        System.out.print(e+"");
       return false;
    }
    }
}
