package ballot;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PADMANABHAN
 */
public class Database {
    Connection conn;
    Statement v;
    ResultSet rs;
    public Database() 
    {
        try{
        conn=DriverManager.getConnection("jdbc:ucanaccess://D://ballot //voting.accdb.mdb");
        v = conn.createStatement();
        }
        catch(Exception e)
        {
            System.out.print(e);
            JOptionPane.showConfirmDialog(null, e);
        }
    }
    boolean checkId(String s) 
    {
        try
        {
            String e;
            e="SELECT VoterId FROM VoterList WHERE VoterId="+s;
            rs=v.executeQuery(e);
            String v=null;
            while(rs.next())
            {
                v=rs.getString("VoterId");
            }
            return false;
        }
        catch(SQLException e)
        {
            System.out.print(e+"");
            return true;
        }
    }
    

    boolean update(String[] g)
    {
        try
        {
            String k;
            k="INSERT INTO VoterList (VoterId,cName,Email,Mobile,VotedFor) VALUES('"+g[0]+"','"+g[1]+"','"+g[2]+"','"+g[3]+"','"+g[4]+"')";
            v.executeUpdate(k);
            System.out.print("sucess");
            return true;
        } 
        catch (SQLException ex)
        {
            System.out.print(ex+"");
            return false;
        }
    }
    boolean checkLogin(String h,String l) 
    {
        try
        {
        String u;
        u="select voterid,password from user where voterid='"+h+"' and password='"+l+"'";
        rs=v.executeQuery(u);
        while(rs.next())
        {
            if(rs.getString("voterid")!=null&&rs.getString("password")!=null)
                return true;
        }
        }
        catch(Exception d)
        {
            System.out.print(d);
            return false;
        }
        return false;
    }
   boolean register(String h[])
    {
        try
        {
            String k;
            k="INSERT INTO user (vNAME,AGE,DOB,EMAIL,PASSWORD,VOTERID,MOBILE,ADDRESS,STATE) VALUES('"+h[0]+"','"+h[1]+"','"+h[2]+"','"+h[3]+"','"+h[4]+"','"+h[5]+"','"+h[6]+"','"+h[7]+"','"+h[8]+"')";
            v.executeUpdate(k);
            System.out.print("sucess");
            return true;
        } 
        catch (SQLException ex)
        {
            System.out.print(ex+"");
            return false;
        }
    }
    
   /* public static void main(String[] args) throws SQLException
    {
        Database r=new Database();
        boolean a=r.checkId("ppp");
       String l[]=new String[6];
       for(int i=0;i<6;i++)
           l[i]="";
       
       r.update(l);
    }*/
}
